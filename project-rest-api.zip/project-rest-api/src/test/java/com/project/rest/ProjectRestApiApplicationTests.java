package com.project.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
